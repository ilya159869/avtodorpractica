<?php

session_start();

include ("dbconnect.php");

 $driverid=$_POST['driverid'];
 echo $driverid;

$sql = "DELETE FROM drivers WHERE driverid = $driverid ";

if (mysqli_query($mysqli, $sql)) {
header('Location:drivers.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
}





?>