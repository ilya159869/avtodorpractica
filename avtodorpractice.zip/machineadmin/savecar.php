<?php
session_start();

	$carmark = $_POST['carmark'];
	$carnumber = $_POST['carnumber'];
	$cardriver = $_POST['cardriver'];
	$carcomment = $_POST['carcomment'];
	$carstatus = $_POST['carstatus'];



include ("dbconnect.php");


$sql = "INSERT INTO cars (carmark,carnumber,cardriver,carcomment,carstatus) VALUES ('$carmark' , '$carnumber' , '$cardriver', '$carcomment', '$carstatus' )";

if (mysqli_query($mysqli, $sql)) {
header('Location:index.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
}





  ?>