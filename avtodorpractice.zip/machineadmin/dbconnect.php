
<?php 
$mysqli = new mysqli ('localhost','root','','avtodor');
if ($mysqli -> connect_error)
{
die('Connect Error ('.$mysqli ->connecterrno.')'.$mysqli -> connect_error);
}

 ?>
