<?php

session_start();

include ("dbconnect.php");

 $carid=$_POST['carid'];
 echo $carid;

$sql = "DELETE FROM cars WHERE carid = $carid ";

if (mysqli_query($mysqli, $sql)) {
header('Location:index.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
}





?>