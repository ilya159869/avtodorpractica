<?php 
session_start();

	$fullname = $_POST['fullname'];
	$phone = $_POST['phone'];
	$drivercomment = $_POST['drivercomment'];


include ("dbconnect.php");


$sql = "INSERT INTO drivers (fullname,phone,drivercomment) VALUES ('$fullname' , '$phone' , '$drivercomment')";

if (mysqli_query($mysqli, $sql)) {
header('Location:drivers.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
}






 ?>