<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Главная страница </title>
	<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>
<body>

<?php session_start(); ?>

<header>

<div style="display: flex; align-items: center;">
<img src="img/logo2.jpg" style="max-height: 110px; border-radius: 50%; "> <h1 class="adminsign" style="padding-left: 20px;"><a href="index.php">Панель администратора </a></h1>
</div>

<div class="navbuttons">
	<div> <button class="navbutton"><a href="drivers.php">Водители</a></button> </div>
</div>


</header>






 <main class="main">
    <div class="container">
      <div class="main-text">
        <p class="main-title">Добавить машину</p>
      </div>
      <table class="table">
<form action="savecar.php" method="post" >
	    <tr>
          <th class="table-title"><input type="text" name="carmark" placeholder="Марка машины..." class="inputbar" required minlength="6"></th>
          <th class="table-title"><input type="text" name="carnumber" placeholder="Номер машины..." required minlength="8" maxlength="8"></th>


          <th class="table-title"> 

          	<select name='cardriver' id='cardriver'>
          	<option value='Нет водителя'>Нет водителя</option>
<?php  

include("dbconnect.php");
$sql = $mysqli -> query ("SELECT fullname FROM drivers");
while ($result = mysqli_fetch_array($sql))
{
$name = $result['fullname'];
?>
<option value='<?php echo $name ?>'><?php echo $name ?></option>
<?php
}
?>
           </th>
          <th class="table-title"><input type="text" name="carcomment" placeholder="Дополнительное описание..."></th>
          <th class="table-title">
<select name='carstatus' id='carstatus'>
<option value='Ожидание'>Ожидание</option>
<option value='Работает'>Работает</option>
<option value='На ремонте'>На ремонте</option>
</select></th>
          <th class="table-title"> <button type="submit">Добавить машину</button> </th>

        </tr>
</form>


</table>
</div>






      <div style="display: flex; justify-content: center;">
      <div class="long-stick"></div>
      </div>

    <?php 
if(isset($_SESSION['success']) && $_SESSION['success']=='true')
{
echo "<script type='text/javascript'>window.onload = function() {alert('Изменения сохранены')};</script>";
  $_SESSION['success'] = 'false';
}
 ?>




 <main class="main">
    <div class="container">
      <div class="main-text">
        <p class="main-title">Список машин</p>
      </div>
      <table class="table">
        <tr>
          <th class="table-title"><b>Марка машины</b></th>
          <th class="table-title"><b>Номер машины</b></th>
          <th class="table-title"><b>Водитель</b></th>
          <th class="table-title"><b>Комментарий</b></th>
          <th class="table-title"><b>Статус</b></th>
          <th class="table-title"><b>Редактирование</b></th>
        </tr>

<?php 

$sql = $mysqli -> query ("SELECT * FROM cars ");

while ($result = mysqli_fetch_array($sql)){

    echo "

<tr>
<td> " . $result["carmark"] . " </td>
<td> " . $result["carnumber"] . " </td>


<form  action='updatecar.php' method='post' >
<input type='hidden' id='carid' name='carid' value='".$result["carid"]."' />
<td> 
          	<select name='cardriver' id='cardriver'>
          	<option value='". $result["cardriver"] ."'>". $result["cardriver"] ."</option> 
          	<option value='Нет водителя'>Нет водителя</option>  ";
          	
$sql2 = $mysqli -> query ("SELECT fullname FROM drivers");
while ($result2 = mysqli_fetch_array($sql2))
{
$name = $result2['fullname'];
echo "<option value='".$name."'> ".$name." </option>";
}
echo "</td>";


echo "<td>
<input type='text' name='carcomment' placeholder='Дополнительное описание...' value = '".$result["carcomment"]."'>
</td>";

echo "<td>
<select name='carstatus' id='carstatus'>
<option value='".$result["carstatus"]."'>".$result["carstatus"]."</option>
<option value='Ожидание'>Ожидание</option>
<option value='Работает'>Работает</option>
<option value='На ремонте'>На ремонте</option>
</td>";

echo "<td>
<button type='submit'>Сохранить изменения</button> 
</form>

<form  action='deletecar.php' method='post' >
<input type='hidden' id='carid' name='carid' value='".$result["carid"]."' />
<button type='submit'>Удалить машину</button> 
</form>

</td></tr>";

  };

?>








      </table>
    </div>
  </main>












</body>
</html>