<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Водители </title>
	<link rel="stylesheet" type="text/css" href="css/style.css">	
</head>
<body>

<header>

<div style="display: flex; align-items: center;">
<img src="img/logo2.jpg" style="max-height: 110px; border-radius: 50%; "> <h1 class="adminsign" style="padding-left: 20px;"><a href="index.php">Панель администратора </a></h1>
</div>

<div class="navbuttons">
	<div> <button class="navbutton"><a href="index.php">Машины</a></button> </div>
</div>


</header>






<div style="display: flex;flex-direction: column;flex-wrap: wrap;align-content: center;">
<table class="carform">
    <p style="font-size: 40px; margin-left: 20px; margin-bottom: -20px;">Добавить водителя</p>
<form action="savedriver.php" method="post" >
	    <tr>
          <th class="table-title"><input type="text" name="fullname" placeholder="Полное имя..."></th>
          <th class="table-title"><input type="text" name="phone" placeholder="Телефонный номер..."></th>

          <th class="table-title"><input type="text" name="drivercomment" placeholder="Дополнительный комментарий..."></th>

          <th class="table-title"> <button type="submit">Добавить водителя</button> </th>
        </tr>
</form>

</table>
</div>


    <?php 
if(isset($_SESSION['success']) && $_SESSION['success']=='true')
{
echo "<script type='text/javascript'>window.onload = function() {alert('Изменения сохранены')};</script>";
  $_SESSION['success'] = 'false';
}
 ?>


      <div style="display: flex; justify-content: center;">
      <div class="long-stick"></div>
      </div>


 <main class="main">
    <div class="container">
      <div class="main-text">
        <p class="main-title">Список водителей</p>
      </div>
      <table class="table">
        <tr>
          <th class="table-title"><b>Полное имя</b></th>
          <th class="table-title"><b>Телефонный номер</b></th>
          <th class="table-title"><b>Комментарий</b></th>
          <th class="table-title"><b>Сохранить изменения</b></th>
        </tr>

<?php 
include("dbconnect.php");
$sql = $mysqli -> query ("SELECT * FROM drivers ");

while ($result = mysqli_fetch_array($sql)){

    echo "
    <tr>

<form  action='updatedrivers.php' method='post' >
<input type='hidden' id='driverid' name='driverid' value='".$result["driverid"]."' />


<td> " . $result["fullname"] . " </td> ";

echo "<td>
<input type='text' name='phone' placeholder='Телефонный номер...' value = '".$result["phone"]."'>
</td>";

echo "<td>
<input type='text' name='drivercomment' placeholder='Дополнительное описание...' value = '".$result["drivercomment"]."'>
</td>";

echo "<td>
<button type='submit'>Сохранить изменения</button> 
</form>";

echo "

<form  action='deletedriver.php' method='post' >
<input type='hidden' id='driverid' name='driverid' value='".$result["driverid"]."' />
<button type='submit'>Удалить водителя</button> 
</form>

</td>";



echo" </tr> ";

}

?>





      </table>
    </div>
  </main>







</body>
</html>