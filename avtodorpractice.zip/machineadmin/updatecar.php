<?php 
session_start();
  include("dbconnect.php");

  
$carid = $_POST['carid'];
$cardriver = $_POST['cardriver'];
$carcomment = $_POST['carcomment'];
$carstatus = $_POST['carstatus'];


$sql = "UPDATE cars SET cardriver ='$cardriver', carcomment ='$carcomment', carstatus ='$carstatus' WHERE carid = '$carid' ";

if (mysqli_query($mysqli, $sql)) {

echo "<script type='text/javascript'>alert('Успешно');</script>";
$_SESSION['success'] = 'true';
header('Location:index.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
}






 ?>