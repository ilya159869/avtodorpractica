<?php 
session_start();
  include("dbconnect.php");

  
$driverid = $_POST['driverid'];
$phone = $_POST['phone'];
$drivercomment = $_POST['drivercomment'];


$sql = "UPDATE drivers SET phone ='$phone', drivercomment ='$drivercomment' WHERE driverid = '$driverid' ";

if (mysqli_query($mysqli, $sql)) {


$_SESSION['success'] = 'true';
header('Location:drivers.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
}






 ?>